import torch
import numpy as np
import os
import os.path as osp
from PIL import Image
from torch.utils import data

class AIRsimDataSetLabel(data.Dataset):
    # for reading CS with labels
    def __init__(self, root, list_path, crop_size=(11, 11), mean=(128, 128, 128), max_iters=None, set='val'):
        self.root = root    # AIRsim
        self.list_path = list_path # list of image names
        self.crop_size = crop_size
        self.mean = mean
        self.img_ids = [i_id.strip() for i_id in open(list_path)]
        if not max_iters==None:
            self.img_ids = self.img_ids * int( np.ceil(float(max_iters)/len(self.img_ids)) )

        self.files = []
        self.ignore_label = 255
        self.set = set

        self.id_to_trainid = {0: 0, 1: 1, 2: 2, 3: 3}

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, index):
        name = self.img_ids[index]
        img_name = name.replace('label', 'image')  
        image = Image.open(osp.join( self.root, "blender_airsim_aligned/airsim/%s" % img_name   )).convert('RGB')
        #lbname = name.replace("frame", "image_")
        label = Image.open(osp.join( self.root, "blender_airsim_aligned/Label_fromJSON/%s" % name   ))
        
        # resize
        image = image.resize( self.crop_size, Image.BICUBIC )
        label = label.resize( self.crop_size, Image.NEAREST )
        
        image = np.asarray( image, np.float32 )
        label = np.asarray( label, np.float32 )

        label_copy = self.ignore_label * np.ones(label.shape, dtype=np.float32)
        label_forBCE = np.zeros((label_copy.shape[0], label_copy.shape[1], 3))
        for i in range(label_forBCE.shape[2]):
            label_forBCE[:,:,i][label == (i+1)] = 1

        size = image.shape
        image = image[:, :, ::-1]  # change to BGR
        image -= self.mean
        image = image.transpose((2, 0, 1))

        return image.copy(), label_forBCE.copy(), np.array(size), name

