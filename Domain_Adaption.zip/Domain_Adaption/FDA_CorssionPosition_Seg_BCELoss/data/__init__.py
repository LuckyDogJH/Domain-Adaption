import numpy as np
from torch.utils import data
from data.Blender_dataset import BlenderDataSet
from data.AIRsim_dataset import AIRsimDataSet
from data.AIRsim_dataset_label import AIRsimDataSetLabel
from data.AIRsim_dataset_SSL import AIRsimDataSetSSL
from data.synthia_dataset import SYNDataSet

IMG_MEAN = np.array((0.0, 0.0, 0.0), dtype=np.float32)
image_sizes = {'AIRsim': (640,375), 'Blender': (652, 376), 'synthia': (1280, 760)}
AS_size_test = {'AIRsim': (652,376)}

def CreateSrcDataLoader(args):
    if args.source == 'Blender':
        source_dataset = BlenderDataSet( args.data_dir, args.data_list, crop_size=image_sizes['AIRsim'], 
                                      resize=image_sizes['Blender'] ,mean=IMG_MEAN,
                                      max_iters=args.num_steps * args.batch_size )
    elif args.source == 'synthia':
        source_dataset = SYNDataSet( args.data_dir, args.data_list, crop_size=image_sizes['AIRsim'],
                                      resize=image_sizes['synthia'] ,mean=IMG_MEAN,
                                      max_iters=args.num_steps * args.batch_size )
    else:
        raise ValueError('The source dataset mush be either Blender or synthia')
    
    source_dataloader = data.DataLoader( source_dataset, 
                                         batch_size=args.batch_size,
                                         shuffle=True, 
                                         num_workers=args.num_workers, 
                                         pin_memory=True )    
    return source_dataloader

def CreateTrgDataLoader(args):
    if args.set == 'train' or args.set == 'trainval':
        target_dataset = AIRsimDataSetLabel( args.data_dir_target, 
                                                 args.data_list_target, 
                                                 crop_size=image_sizes['AIRsim'], 
                                                 mean=IMG_MEAN, 
                                                 max_iters=args.num_steps * args.batch_size, 
                                                 set=args.set )
    else:
        target_dataset = AIRsimDataSet( args.data_dir_target,
                                            args.data_list_target,
                                            crop_size=AS_size_test['AIRsim'],
                                            mean=IMG_MEAN,
                                            set=args.set )

    if args.set == 'train' or args.set == 'trainval':
        target_dataloader = data.DataLoader( target_dataset,
                                             batch_size=args.batch_size,
                                             shuffle=True,
                                             num_workers=args.num_workers,
                                             pin_memory=True )
    else:
        target_dataloader = data.DataLoader( target_dataset,
                                             batch_size=1, 
                                             shuffle=False, 
                                             pin_memory=True )

    return target_dataloader



def CreateTrgDataSSLLoader(args):
    target_dataset = AIRsimDataSet( args.data_dir_target, 
                                        args.data_list_target,
                                        crop_size=image_sizes['AIRsim'],
                                        mean=IMG_MEAN, 
                                        set=args.set )
    target_dataloader = data.DataLoader( target_dataset, 
                                         batch_size=1, 
                                         shuffle=False, 
                                         pin_memory=True )
    return target_dataloader



def CreatePseudoTrgLoader(args):
    target_dataset = AIRsimDataSetSSL( args.data_dir_target,
                                           args.data_list_target,
                                           crop_size=image_sizes['AIRsim'],
                                           mean=IMG_MEAN,
                                           max_iters=args.num_steps * args.batch_size,
                                           set=args.set,
                                           label_folder=args.label_folder )

    target_dataloader = data.DataLoader( target_dataset,
                                         batch_size=args.batch_size,
                                         shuffle=True,
                                         num_workers=args.num_workers,
                                         pin_memory=True )

    return target_dataloader

