import numpy as np
from PIL import Image
from utils import FDA_source_to_target_np
import scipy.misc
import cv2

im_src = Image.open("/content/FDA_Drone_Data/FDA/images/image_002469.png").convert('RGB')
im_trg = Image.open("/content/FDA_Drone_Data/FDA/airsim_images/images/frame000314.png").convert('RGB')


im_src = im_src.resize( (512,256), Image.BICUBIC )
im_trg = im_trg.resize( (512,256), Image.BICUBIC )

im_src = np.asarray(im_src, np.float32)
im_trg = np.asarray(im_trg, np.float32)

im_src = im_src.transpose((2, 0, 1)) #Tranpose OpenCV_format(H*W*C) to C*H*W 
im_trg = im_trg.transpose((2, 0, 1))

src_in_trg = FDA_source_to_target_np( im_src, im_trg, L=0.03)
src_in_trg = src_in_trg.transpose((1,2,0))
cv2.imwrite('/content/result/src_in_tar.png', src_in_trg)

#scipy.misc.toimage(src_in_trg, cmin=0.0, cmax=255.0).save('/content/drive/MyDrive/FDA-master/demo_images/src_in_tar.png')


